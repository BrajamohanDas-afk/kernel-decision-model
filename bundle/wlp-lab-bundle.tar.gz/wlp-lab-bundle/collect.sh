#!/usr/bin/env bash
# WorkloadPilot data-collection kit — one command. Usage: sudo bash collect.sh [extra args]
set -e
cd "$(dirname "$0")"
if [ "$(id -u)" != "0" ]; then
  echo "please run with sudo:  sudo bash collect.sh"
  exit 1
fi
RUNS="${RUNS:-24}"
BASE="$(pwd)"
echo "== WorkloadPilot data collection =="
echo "runs: $RUNS (each ~3.5 min; change with:  RUNS=40 sudo bash collect.sh)"
mkdir -p "$BASE/runs"
python3 "$BASE/lab/dsv2/run_batch.py" --runs "$RUNS" --start-seed 1 --mode-mix 0.7 \
  --runs-dir "$BASE/runs" "$@"
echo
echo "== collection finished — packing results =="
tar -czf "$BASE/wlp-results.tar.gz" runs
ls -la "$BASE/wlp-results.tar.gz"
echo
echo "DONE. Please send back the file:  wlp-results.tar.gz"
